<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeIdInboxGlobalInboxGlobalsTable extends Migration
{
    public function __construct() 
    {
        DB::getDoctrineSchemaManager()->getDatabasePlatform()->registerDoctrineTypeMapping('enum', 'string');
    }
    
    public function up()
    {
        Schema::table('inbox_globals', function(Blueprint $table)
        {
            $table->renameColumn('id_user_inbox_global', 'id_inbox_global');
        });
    }

    public function down()
    {
        Schema::table('inbox_globals', function(Blueprint $table)
        {
            $table->renameColumn('id_inbox_global', 'id_user_inbox_global');
        });
    }
}
