<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Autocrm\\Providers\\AutocrmServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Autocrm\\Providers\\AutocrmServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);