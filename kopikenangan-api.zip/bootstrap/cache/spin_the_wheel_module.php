<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SpinTheWheel\\Providers\\SpinTheWheelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SpinTheWheel\\Providers\\SpinTheWheelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);