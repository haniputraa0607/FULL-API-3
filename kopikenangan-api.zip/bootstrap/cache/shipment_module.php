<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Shipment\\Providers\\ShipmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Shipment\\Providers\\ShipmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);