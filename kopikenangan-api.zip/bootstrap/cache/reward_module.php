<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);