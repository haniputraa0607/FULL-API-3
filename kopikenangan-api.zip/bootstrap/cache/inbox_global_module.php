<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\InboxGlobal\\Providers\\InboxGlobalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\InboxGlobal\\Providers\\InboxGlobalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);