<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Advert\\Providers\\AdvertServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Advert\\Providers\\AdvertServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);