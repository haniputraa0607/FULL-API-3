<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\OutletApp\\Providers\\OutletAppServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\OutletApp\\Providers\\OutletAppServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);