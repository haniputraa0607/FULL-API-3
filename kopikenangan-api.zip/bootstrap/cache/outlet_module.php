<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Outlet\\Providers\\OutletServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Outlet\\Providers\\OutletServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);