<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Promotion\\Providers\\PromotionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Promotion\\Providers\\PromotionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);