<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SettingFraud\\Providers\\SettingFraudServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SettingFraud\\Providers\\SettingFraudServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);