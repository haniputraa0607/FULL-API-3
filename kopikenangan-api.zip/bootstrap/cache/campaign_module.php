<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Campaign\\Providers\\CampaignServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Campaign\\Providers\\CampaignServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);