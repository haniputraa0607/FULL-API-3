<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Balance\\Providers\\BalanceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Balance\\Providers\\BalanceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);