<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Transaction\\Providers\\TransactionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Transaction\\Providers\\TransactionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);