<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Enquiries\\Providers\\EnquiriesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Enquiries\\Providers\\EnquiriesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);