<?php

return [
    'name' => 'Users'
];
