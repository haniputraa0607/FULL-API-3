<?php

namespace App\Http\Middleware;

use Closure;
use App\Http\Models\LogRequest;

class LogRequestMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
		$response = $next($request);

		$user = json_encode($request->user());
		$url = $request->url();
		$user = json_decode(json_encode($request->user()), true);
		$st = stristr(json_encode($response),'success');
		$status = 'fail';
		if($st) $status = 'success';
		$reqnya = $request->json()->all();
		if(isset($reqnya['pin'])) $reqnya['pin'] = "******";
		if(isset($reqnya['pin_old'])) $reqnya['pin'] = "******";
		if(isset($reqnya['pin_new'])) $reqnya['pin'] = "******";
		$requestnya = json_encode($reqnya);
		$requeste = json_decode($requestnya, true);

		$phone = $user['phone'];
		$id_store = null;
		if(isset($requeste['phone']))
			$phone = $requeste['phone'];
		
		if($requestnya == '[]') $requestnya = null;
		$urlexp = explode('/',$url);
		
		$subject = "Unknown";
		$module = $urlexp[6];
		if(stristr($url, 'users/pin/create')) $subject = 'User Register';
		if(stristr($url, 'users/pin/check')) $subject = 'User Login Attempt';
		if(stristr($url, 'users/phone/check')) $subject = 'Phone Check';
		if(stristr($url, 'users/pin/resend')) $subject = 'Resend PIN';
		if(stristr($url, 'users/pin/forgot')) $subject = 'Forgot PIN';
		if(stristr($url, 'pos/check/member')) { $subject = 'POS Check Member'; $module = $urlexp[7]; }
		if(stristr($url, 'pos/check/voucher')) { $subject = 'POS Check Voucher'; $module = $urlexp[7]; }
		if(stristr($url, 'pos/menu')) $subject = 'POS Menu Sync';
		if(stristr($url, 'pos/transaction')) $subject = 'POS Transaction Sync';
		if(stristr($url, 'pos/transaction/refund')) $subject = 'POS Transaction Refund';
		if(stristr($url, 'product/delete')) $subject = 'Delete Product'; $module = $urlexp[4];
		
		if(!empty($user) && $user != ""){
			$data = [
				'module' 			=> $module,
				'url' 				=> $url,
				'subject' 			=> $subject,
				'phone' 			=> $phone,
				'user' 				=> json_encode($request->user()),
				'request' 			=> $requestnya,
				'response_status' 	=> $status,
				'response' 			=> json_encode($response),
				'ip' 				=> $request->ip(),
				'useragent' 		=> $request->header('user-agent')
			  ];
		} else{
			$data = [
				'module' 			=> $module,
				'url' 				=> $url,
				'subject' 			=> $subject,
				'phone' 			=> $phone,
				'user' 				=> null,
				'request' 			=> $requestnya,
				'response_status' 	=> $status,
				'response' 			=> json_encode($response),
				'ip' 				=> $request->ip(),
				'useragent' 		=> $request->header('user-agent')
			  ];
		}
		
		$log = LogRequest::create($data);
		return $response;
    }
}
